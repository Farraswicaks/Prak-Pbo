//Author : Rudiyanto
//28 April 2019
//Program Library and Coffee Shop
//Main Class

package PrakPbo;

public class Project {

    public static void main(String[] args) {
          new ViewLogin();
    }
    
}
